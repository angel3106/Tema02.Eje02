package ejercicio2;

import java.util.ArrayList;

public class DeckCards {

	public static void main(String[] args) {

		String[] suits = { "Spades", "Diamonds", "Club", "Heart" };//da valores a suit 
		String[] values = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };//da valores a value

		ArrayList<Card> deck = new ArrayList<Card>();//almacena la información de suit y value

		for (int i = 0; i < suits.length; i++) {//genera el mazo
			for (int j = 0; j < values.length; j++) {
				Card card = new Card(suits[i], values[j]);
				deck.add(card);
			}
		}

		for (int i = 0; i < deck.size(); i++) {//genera de manera aleatoria un conjunto de cartas
			int j = (int) Math.floor(Math.random() * i);//math floor para obtener el numero double mas largo,y random para generar el mazo de forma aleatoria
			Card tmp = deck.get(i);
			deck.set(i, deck.get(j));
			deck.set(j, tmp);
		}

		for (int i = 0; i < 5; i++) {//muestra las 5 primeras cartas generadas de forma aleatoria anteriormente
			System.out.println(deck.get(i));
		}

	}

}
