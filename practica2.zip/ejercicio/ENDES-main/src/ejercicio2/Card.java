package ejercicio2;

public class Card {

	public String suit;//variables tipo string
	public String value;
	
	public Card (String suit, String value) {
		this.suit = suit;//llama a suit de el archivo deckcards
		this.value = value;//llama a value de el archivo deckcards
	}
	
	public String toString () {
		return (this.suit+"-"+this.value);//devuelve el palo y valor de carta 
	}
}
